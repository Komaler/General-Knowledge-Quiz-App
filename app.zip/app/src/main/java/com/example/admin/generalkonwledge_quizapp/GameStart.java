package com.example.admin.generalkonwledge_quizapp;


import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class GameStart extends AppCompatActivity {

    private static final String TAG = "GameStart";
    private static final String KEY_INDEX = "index";

    private Button mTrueButton,end;
    private Button mFalseButton;
    private Button mNextButton;
    private Button mPreviousButton;
    private TextView mScoreView;
    private int mScore = 0;
    private int mQuestionNumber = 0;
    private TextView mQuestionTextView;

    public static Questions[] mQuestionBank = new Questions[] {
            new Questions(R.string.question_q1,true),
            new Questions(R.string.question_q2,true),
            new Questions(R.string.question_q3,true),
            new Questions(R.string.question_q4,false),
            new Questions(R.string.question_q5,false),
            new Questions(R.string.question_q6,true),
            new Questions(R.string.question_q7,false),
            new Questions(R.string.question_q8,true),
            new Questions(R.string.question_q9,true),
            new Questions(R.string.question_q10,true),
            new Questions(R.string.question_q11,false),
            new Questions(R.string.question_q12,true),
            new Questions(R.string.question_q13,false),
            new Questions(R.string.question_q14,true),
            new Questions(R.string.question_q15,true),
            new Questions(R.string.question_q16,true),
            new Questions(R.string.question_q17,true),
            new Questions(R.string.question_q18,true),
            new Questions(R.string.question_q19,true),
            new Questions(R.string.question_q20,false),
            new Questions(R.string.question_q21,false),
            new Questions(R.string.question_q22,true),
            new Questions(R.string.question_q23,true),
            new Questions(R.string.question_q24,true),
            new Questions(R.string.question_q25,false),
            new Questions(R.string.question_q26,true),
            new Questions(R.string.question_q27,true),
            new Questions(R.string.question_q28,true),
            new Questions(R.string.question_q29,true),
            new Questions(R.string.question_q30,true),




    };

    private int mCurrentIndex = 0;

    private void updateQuestions(){
        int question = mQuestionBank[mCurrentIndex].getmTextResId();
        mQuestionTextView.setText(question);
    }
    private void updateScore(int point) {
        mScoreView.setText("" + mScore);
    }



        private void checkAnswer(boolean userPressedTrue){
        boolean answerIsTrue = mQuestionBank[mCurrentIndex].ismAnswerTrue();
        int messageResId = 0;
        if (userPressedTrue == answerIsTrue) {
            messageResId = R.string.correct_toast;
            mScore++;
            updateScore(mScore);
            if (mQuestionNumber == mQuestionBank.length) {
                Bundle bundle = new Bundle();
                bundle.putInt("finalScore", mScore);
                GameStart.this.finish();
            }
        }else{
            messageResId = R.string.incorrect_toast;
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT).show();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_start);
        end=(Button)findViewById(R.id.end);

        mQuestionTextView = (TextView) findViewById(R.id.question_text_view);
        mScoreView = (TextView)findViewById(R.id.points);
        mTrueButton = (Button) findViewById(R.id.true_button);
        //Logic for true button
        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                checkAnswer(true);

            }
        });


        mFalseButton = (Button) findViewById(R.id.false_button);
        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){

                checkAnswer(false);

            }
        });

        mNextButton = (Button) findViewById(R.id.next_button);
        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                mCurrentIndex = (mCurrentIndex + 1) % mQuestionBank.length;
               updateQuestions();
            }

        });

        mPreviousButton = (Button) findViewById(R.id.previous_button);
        mPreviousButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                mCurrentIndex = (mCurrentIndex - 1 + mQuestionBank.length) % mQuestionBank.length ;
                updateQuestions();
            }
        });



        if (savedInstanceState != null){
            mCurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
        }
        updateQuestions();



        end.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                Intent i=new Intent(getApplicationContext(), ResultsActivity.class);
                startActivity(i);
                finish();
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        Log.i(TAG, "onSaveInstancesSate");
        savedInstanceState.putInt(KEY_INDEX, mCurrentIndex);
    }
}
